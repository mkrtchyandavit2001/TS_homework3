import './App.css'
import { EventList } from './components/EventList'
import { Filter } from './components/Filter'

function App() {
  return <>
    <Filter/>
    <EventList/>
  </>
}

export default App
