export const AddEvent = () => {
    return <>
        <h1>Add</h1>
    </>
}