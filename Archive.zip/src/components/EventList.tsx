export const EventList:React.FC = () => {
    return <>
        <h1>Event List</h1>
    </>
}